# hunspell-th
This hunspell dictionary is based on NECTEC's 2005 version.
This dictionary contains 51683 words (compared to 39792 words of NECTEC's version).
Most of the additional words are from [TLWG's libthai](https://github.com/tlwg/libthai) data.
 
